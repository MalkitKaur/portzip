// Importing the 'prompt' library to handle user input from the command line
const promptLib = require('prompt');

// Starting the prompt interface
promptLib.start();

// Defining the input schema for user input
const input = {
    properties: {
        userSelection: {
            description: 'Hey !! Choose between ROCK, PAPER, or SCISSORS',
            type: 'string',
            pattern: /^(ROCK|PAPER|SCISSORS)$/i,
            message: 'Please select anything between ROCK, PAPER, or SCISSORS',
            required: true
        }
    }
};

// Getting the user input
promptLib.get(input, function (error, userInput) {
    // Handling any errors that occur
    if (error) {
        return handleError(error);
    }
    // Converting the user's selection to uppercase to standardize the input
    const userSelection = userInput.userSelection.toUpperCase();
    console.log(`The player selected: ${userSelection}`);
    // Generating a random number to decide the computer's selection
    const randomNumber = Math.random();
    let computerSelection;
    if (randomNumber < 0.34) {
        computerSelection = 'PAPER';
    } else if (randomNumber <= 0.67) {
        computerSelection = 'SCISSORS';
    } else {
        computerSelection = 'ROCK';
    }
    console.log(`The machine selected: ${computerSelection}`);

    // Determining the outcome of the match
    let matchOutput;
    if (userSelection === computerSelection) {
        matchOutput = "It's a tie !!";
    } else if (
        (userSelection === 'ROCK' && computerSelection === 'SCISSORS') ||
        (userSelection === 'PAPER' && computerSelection === 'ROCK') ||
        (userSelection === 'SCISSORS' && computerSelection === 'PAPER')
    ) {
        matchOutput = 'Player Wins !!';
    } else {
        matchOutput = 'Machine Wins !!';
    }

    console.log(matchOutput);
});

// Function for handling errors
function handleError(error) {
    console.log(error);
    return 1;
}